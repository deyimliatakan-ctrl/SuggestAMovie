# Movie Suggester React App

## Requirements:
1. Node.js and npm installed on your system.
2. TMDb API Key: Insert your API key in the `.env` file.

## Steps to run the application:

1. Clone the project or download the zip.
2. Extract the files to a directory.
3. Open a terminal in the project directory.
4. Run `npm install` to install dependencies.
5. Run `npm start` to start the app.
6. Open a browser and go to `http://localhost:3000`.

## Features:
- Filters for movie genres, release years, rating, and runtime.
- Shows a randomly suggested movie based on the filters.
